# air_clean_robot

ROS2 Humble package that reads PMS7003 air quality values from Arduino USB Serial and dispatches TurtleBot3 Nav2 goals when PM2.5 is high.

## Project Structure

```text
air_clean_robot/
  air_clean_robot/
    serial_air_quality_node.py
    sim_air_quality_publisher.py
    air_quality_task_manager.py
    manual_nav_controller.py
    air_clean_gui.py
  config/
    air_clean_params.yaml
  launch/
    air_clean_serial.launch.py
    air_clean_sim.launch.py
  package.xml
  setup.py
```

## Current Structure

```text
PMS7003 -> Arduino -> USB Serial -> ROS2 -> Nav2
```

Runtime flow:

```text
PMS7003 -> Arduino -> USB Serial -> serial_air_quality_node -> /air_quality -> air_quality_task_manager -> Nav2 NavigateToPose
```

## Future Extension

Later, the serial input can be replaced or supplemented with MQTT:

```text
PMS7003 -> ESP8266 -> MQTT -> ROS2 -> Nav2
```

Do not change `air_quality_task_manager` for MQTT. Add a future `mqtt_air_quality_node` that publishes the same `/air_quality` JSON string format.

## /air_quality JSON Format

Topic type:

```text
std_msgs/msg/String
```

Payload:

```json
{
  "zone": "A",
  "pm1_0": 10,
  "pm2_5": 35,
  "pm10": 50,
  "source": "serial"
}
```

Any future MQTT input node must publish this same JSON format to `/air_quality`.

## Arduino Serial Output Examples

`serial_air_quality_node` accepts all of these formats:

```text
PM1.0:12,PM2.5:35,PM10:50
PM1.0=12, PM2.5=35, PM10=50
12,35,50
```

Arduino serial settings:

```text
baudrate: 9600
port example: /dev/ttyACM0
```

## Build

```bash
cd ~/group4_ws
colcon build --packages-select air_clean_robot
source install/setup.bash
```

## Sensor-Free FSM Test

This launches the simulator and task manager. The launch file overrides `use_nav2=false`, so TurtleBot3 and Nav2 are not required.

```bash
cd ~/group4_ws
source install/setup.bash
ros2 launch air_clean_robot air_clean_sim.launch.py
```

Change simulation mode in `config/air_clean_params.yaml`:

```yaml
sim_air_quality_publisher:
  ros__parameters:
    mode: "dirty"
```

`dirty` triggers the FSM. `normal` keeps PM2.5 below the threshold.

## Real Sensor Test

Connect Arduino and PMS7003, then run:

```bash
cd ~/group4_ws
source install/setup.bash
ros2 launch air_clean_robot air_clean_serial.launch.py
```

Check the topic:

```bash
ros2 topic echo /air_quality
```

If the serial node cannot open `/dev/ttyACM0`, check the actual port and edit `config/air_clean_params.yaml`.

## TurtleBot3 Nav2

For real robot movement, TurtleBot3 Nav2 must already be running and localized on a map. Example:

```bash
export TURTLEBOT3_MODEL=waffle_pi
ros2 launch turtlebot3_navigation2 navigation2.launch.py map:=$HOME/map.yaml
```

Then run the serial launch with `use_nav2: true` in `config/air_clean_params.yaml`.

Set these coordinates in `config/air_clean_params.yaml` using RViz goal poses from your actual map:

```yaml
dirty_zone_x: 1.0
dirty_zone_y: 0.0
dirty_zone_yaw: 0.0
home_x: 0.0
home_y: 0.0
home_yaw: 0.0
```

## Manual Navigation Test Without Sensor

If the map and TurtleBot3 Nav2 are already running, you can move to a configured target pose and return home without using the PMS sensor.

Start the manual controller:

```bash
cd ~/group4_ws
source install/setup.bash
ros2 launch air_clean_robot air_clean_manual.launch.py
```

Send the robot to the configured target pose:

```bash
ros2 topic pub --once /air_clean_command std_msgs/msg/String "{data: 'go'}"
```

Return to the configured home pose:

```bash
ros2 topic pub --once /air_clean_command std_msgs/msg/String "{data: 'home'}"
```

The same command topic can later be connected to a GUI button, joystick button, or web button. The navigation controller only needs `std_msgs/msg/String` commands on `/air_clean_command`.

Configure the manual target and home poses in `config/air_clean_params.yaml`:

```yaml
manual_nav_controller:
  ros__parameters:
    target_x: 1.0
    target_y: 0.0
    target_yaw: 0.0
    home_x: 0.0
    home_y: 0.0
    home_yaw: 0.0
```

## GUI Manual Control

This starts the manual Nav2 controller and a simple desktop GUI. The GUI publishes the same `/air_clean_command` messages used by the terminal commands.
It also displays the live Nav2 map from `/map`, the robot pose from `/amcl_pose`, and the configured target/home markers.

```bash
cd ~/group4_ws
source install/setup.bash
ros2 launch air_clean_robot air_clean_gui.launch.py
```

GUI buttons:

```text
Go To Target -> publishes "go"
Return Home  -> publishes "home"
Close GUI    -> closes the GUI window
```

The target and home coordinates are still configured in `config/air_clean_params.yaml` under `manual_nav_controller`.
For the map display, keep the GUI marker coordinates matched under `air_clean_gui`:

```yaml
air_clean_gui:
  ros__parameters:
    map_topic: "/map"
    robot_pose_topic: "/amcl_pose"
    target_x: 1.0
    target_y: 0.0
    home_x: 0.0
    home_y: 0.0
```

## Notes

- ESP8266/MQTT is intentionally not implemented yet.
- The fixed integration contract is `/air_quality` with `std_msgs/msg/String` JSON.
- The task manager stores PM2.5 per zone and uses a rolling average.
- States are `IDLE`, `GO_TO_DIRTY_ZONE`, `CLEANING`, `RETURN_HOME`, and `ERROR`.
- With `use_nav2=false`, the FSM logs simulated navigation and can be tested without TurtleBot3.
